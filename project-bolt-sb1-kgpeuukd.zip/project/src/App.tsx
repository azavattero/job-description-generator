import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';
import FormField from '@/components/FormField';
import LocationSelect from '@/components/LocationSelect';
import PreviewCard from '@/components/PreviewCard';
import { BENEFITS_MAP, NON_SALARIED_KEYS } from '@/lib/benefits';
import { formatBullets } from '@/lib/utils';

interface FormState {
  reportsTo: string;
  collaboratesWith: string;
  primaryResponsibility: string;
  whatYouDo: string;
  whatQualifiesYou: string;
  whatsInItForYou: string;
  physicalDemands: string;
  technicalSkills: string;
  educationLicensing: string;
  workingConditions: string;
  culturalValues: string;
}

function App() {
  const [form, setForm] = useState<FormState>({
    reportsTo: '',
    collaboratesWith: '',
    primaryResponsibility: '',
    whatYouDo: '',
    whatQualifiesYou: '',
    whatsInItForYou: '',
    physicalDemands: '',
    technicalSkills: '',
    educationLicensing: '',
    workingConditions: '',
    culturalValues: ''
  });

  const [location, setLocation] = useState('');
  const [output, setOutput] = useState('');
  const [hasMounted, setHasMounted] = useState(false);
  const [showNote, setShowNote] = useState(false);
  const activeFieldRef = useRef<HTMLTextAreaElement | HTMLInputElement | null>(null);

  useEffect(() => {
    setHasMounted(true);
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    const bulletFields = [
      'whatYouDo',
      'whatQualifiesYou',
      'physicalDemands',
      'technicalSkills',
      'educationLicensing',
      'workingConditions',
      'culturalValues',
      'whatsInItForYou'
    ];
    
    const updatedValue = bulletFields.includes(name)
      ? value
          .split('\n')
          .map(line => (line.trim() === '' ? '' : line.trim().startsWith('•') ? line : `• ${line.trim()}`))
          .join('\n')
      : value;

    setForm({ ...form, [name]: updatedValue });
  };

  const handleLocationChange = (value: string) => {
    setLocation(value);
    setForm({ ...form, whatsInItForYou: BENEFITS_MAP[value] || '' });
    setShowNote(NON_SALARIED_KEYS.includes(value));
  };

  const handleFocus = (e: React.FocusEvent<HTMLTextAreaElement | HTMLInputElement>) => {
    activeFieldRef.current = e.target;
  };

  const generateDescription = () => {
    let description = `
<strong>Reports to:</strong> ${form.reportsTo}<br>
<strong>Collaborates with:</strong> ${form.collaboratesWith}<br>
<strong>Primary Responsibility:</strong> ${form.primaryResponsibility}<br>`;

    if (showNote) {
      description += `<strong>What's in it for You:</strong><br>${formatBullets(form.whatsInItForYou)}<br>`;
    }

    description += `<strong>What You'll Do:</strong><br>${formatBullets(form.whatYouDo)}<br>
<strong>What Qualifies You:</strong><br>${formatBullets(form.whatQualifiesYou)}<br>`;

    if (!showNote) {
      description += `<strong>What's in it for You:</strong><br>${formatBullets(form.whatsInItForYou)}<br>`;
    }

    if (form.physicalDemands) {
      description += `<strong>Physical Demands and Requirements:</strong><br>${formatBullets(form.physicalDemands)}<br>`;
    }
    if (form.technicalSkills) {
      description += `<strong>Technical Skill Requirements:</strong><br>${formatBullets(form.technicalSkills)}<br>`;
    }
    if (form.educationLicensing) {
      description += `<strong>Educational/Licensing Requirements:</strong><br>${formatBullets(form.educationLicensing)}<br>`;
    }
    if (form.workingConditions) {
      description += `<strong>Working Conditions:</strong><br>${formatBullets(form.workingConditions)}<br>`;
    }
    if (form.culturalValues) {
      description += `<strong>Cultural Values:</strong><br>${formatBullets(form.culturalValues)}<br>`;
    }

    description += `<em>Equal Opportunity: MIRATECH is an equal opportunity employer and supports a diverse and inclusive workforce. All employment practices are based on qualification and merit, without regards to race, color, national origin, ancestry, religion, age, sex, gender identity, sexual orientation or preference, marital status or spousal affiliation, physical or mental disability, medical conditions, pregnancy, status as a protected veteran, genetic information, or citizenship within the limits imposed by federal laws and regulations.</em>`;

    setOutput(description);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <Card className="mb-6 border-none shadow-lg transition-all duration-300 hover:shadow-xl">
          <CardHeader className="bg-blue-600 text-white rounded-t-lg pb-4">
            <div className="flex items-center gap-2">
              <FileText className="h-6 w-6" />
              <CardTitle>Job Description Generator</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                label="Reports To"
                name="reportsTo"
                value={form.reportsTo}
                onChange={handleChange}
                onFocus={handleFocus}
                placeholder=""
              />
              <FormField
                label="Collaborates With"
                name="collaboratesWith"
                value={form.collaboratesWith}
                onChange={handleChange}
                onFocus={handleFocus}
                placeholder="e.g. Sales, Engineering, Assembly, HR"
              />
            </div>
            
            <FormField
              label="Primary Responsibility"
              name="primaryResponsibility"
              value={form.primaryResponsibility}
              onChange={handleChange}
              onFocus={handleFocus}
              placeholder="Describe the role's main responsibilities in 2-3 sentences"
            />
            
            <LocationSelect value={location} onChange={handleLocationChange} />
            
            <FormField
              label="What You'll Do"
              name="whatYouDo"
              value={form.whatYouDo}
              onChange={handleChange}
              onFocus={handleFocus}
              multiline
              rows={5}
              isBulletField
              placeholder="• List job duties here (one per line)"
            />
            
            <FormField
              label="What Qualifies You"
              name="whatQualifiesYou"
              value={form.whatQualifiesYou}
              onChange={handleChange}
              onFocus={handleFocus}
              multiline
              rows={5}
              isBulletField
              placeholder="• List qualifications here (one per line)"
            />
            
            {!location && (
              <FormField
                label="What's In It For You"
                name="whatsInItForYou"
                value={form.whatsInItForYou}
                onChange={handleChange}
                onFocus={handleFocus}
                multiline
                rows={5}
                isBulletField
                placeholder="• List benefits here (one per line)"
              />
            )}
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                label="Physical Demands (Optional)"
                name="physicalDemands"
                value={form.physicalDemands}
                onChange={handleChange}
                onFocus={handleFocus}
                multiline
                rows={3}
                isBulletField
                placeholder="• List physical requirements (optional)"
              />
              
              <FormField
                label="Technical Skills (Optional)"
                name="technicalSkills"
                value={form.technicalSkills}
                onChange={handleChange}
                onFocus={handleFocus}
                multiline
                rows={3}
                isBulletField
                placeholder="• List technical skills (optional)"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                label="Education/Licensing (Optional)"
                name="educationLicensing"
                value={form.educationLicensing}
                onChange={handleChange}
                onFocus={handleFocus}
                multiline
                rows={3}
                isBulletField
                placeholder="• List education requirements (optional)"
              />
              
              <FormField
                label="Working Conditions (Optional)"
                name="workingConditions"
                value={form.workingConditions}
                onChange={handleChange}
                onFocus={handleFocus}
                multiline
                rows={3}
                isBulletField
                placeholder="• List working conditions (optional)"
              />
            </div>
            
            <FormField
              label="Cultural Values (Optional)"
              name="culturalValues"
              value={form.culturalValues}
              onChange={handleChange}
              onFocus={handleFocus}
              multiline
              rows={3}
              isBulletField
              placeholder="• List cultural values (optional)"
            />
            
            <div className="mt-6">
              <Button 
                onClick={generateDescription}
                className="w-full md:w-auto bg-blue-600 hover:bg-blue-700 text-white transition-colors duration-200"
              >
                Generate Job Description
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {hasMounted && output && (
          <PreviewCard output={output} form={form} showNote={showNote} />
        )}
      </div>
    </div>
  );
}

export default App;