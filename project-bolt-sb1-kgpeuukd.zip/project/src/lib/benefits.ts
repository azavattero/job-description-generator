export const BENEFITS_MAP: Record<string, string> = {
  'Houston 2nd Shift': `• Health, Dental & Vision Insurance
• Annual Bonus Program
• $350 Annual Wellness Credit
• Flexible Spending Account (FSA)
• 401k with match up to 5%
• Life insurance
• Disability insurance
• 5 days of paid sick leave annually (prorated based on start date)
• 12 days PTO annually (prorated based on start date)
• $350 Production reimbursement program`,
  'Prior Lake, 2nd Shift': `• Health, Dental & Vision Insurance
• Annual Bonus Program
• $350 Annual Wellness Credit
• Flexible Spending Account (FSA)
• 401k with match up to 5%
• Life insurance
• Disability insurance
• 5 days of paid sick leave annually (prorated based on start date)
• 12 days PTO annually (prorated based on start date)
• $350 Production reimbursement program`,
  'Hourly Position, 8 hour, Prior Lake': `• Health, Dental & Vision Insurance
• Annual Bonus Program
• $350 Annual Wellness Credit
• Flexible Spending Account (FSA)
• 401k with match up to 5%
• Life insurance
• Disability insurance
• 6 days of paid sick leave annually
• 15 days PTO annually (prorated based on start date)
• $350 Production Reimbursement Program`,
  'Hourly Position, 8 hour, Tulsa/Houston/Knoxville': `• Health, Dental & Vision Insurance
• Annual Bonus Program
• $350 Annual Wellness Credit
• Flexible Spending Account (FSA)
• 401k with match up to 5%
• Life insurance
• Disability insurance
• 5 days of paid sick leave annually (prorated based on start date)
• 15 days PTO annually (prorated based on start date)
• $350 Production Reimbursement Program`,
  'Hourly Position, 8 hour, Houston Fitter': `• Hourly pay based on experience.
• Competitive starting pay for entry-level candidates who pass the welding test.
• Health, Dental & Vision Insurance
• Annual Bonus Program
• $350 Annual Wellness Credit
• Flexible Spending Account (FSA)
• 401k with match up to 5%
• Life insurance
• Disability insurance
• 5 days of paid sick leave annually (prorated based on start date)
• 15 days PTO annually (prorated based on start date)
• $350 Production Reimbursement Program`,
  'Salaried Employees in Tulsa/Houston/Knoxville': `• Health, Dental & Vision Insurance
• Annual Bonus Program
• $350 Annual Wellness Credit
• Flexible Spending Account (FSA)
• 401k with match up to 5%
• Life insurance
• Disability insurance
• 5 days of paid sick leave annually (prorated based on start date)
• 15 days PTO annually (prorated based on start date)`,
  'Salaried Employees in Prior Lake': `• Health, Dental & Vision Insurance
• Annual Bonus Program
• $350 Annual Wellness Credit
• Flexible Spending Account (FSA)
• 401k with match up to 5%
• Life insurance
• Disability insurance
• 6 days of paid sick leave annually
• 15 days PTO annually (prorated based on start date)`
};

export const NON_SALARIED_KEYS = Object.keys(BENEFITS_MAP).filter(
  key => !key.includes('Salaried Employees')
);