import { Document, Packer, Paragraph, TextRun, convertInchesToTwip } from 'docx';
import { saveAs } from 'file-saver';

interface FormData {
  reportsTo: string;
  collaboratesWith: string;
  primaryResponsibility: string;
  whatYouDo: string;
  whatQualifiesYou: string;
  whatsInItForYou: string;
  physicalDemands: string;
  technicalSkills: string;
  educationLicensing: string;
  workingConditions: string;
  culturalValues: string;
}

export const generateWordDocument = (form: FormData, showNote: boolean) => {
  const doc = new Document({
    styles: {
      default: {
        document: {
          run: {
            font: "Verdana",
            size: 18, // 9pt * 2 = 18 half-points
          },
        },
      },
    },
    sections: [{
      properties: {
        page: {
          margin: {
            top: convertInchesToTwip(1),
            right: convertInchesToTwip(1),
            bottom: convertInchesToTwip(1),
            left: convertInchesToTwip(1),
          },
        },
      },
      children: [
        new Paragraph({ 
          children: [
            new TextRun({ text: `Reports to: `, bold: true }),
            new TextRun(form.reportsTo)
          ]
        }),
        new Paragraph({ 
          children: [
            new TextRun({ text: `Collaborates with: `, bold: true }),
            new TextRun(form.collaboratesWith)
          ]
        }),
        new Paragraph({ 
          children: [
            new TextRun({ text: `Primary Responsibility: `, bold: true }),
            new TextRun(form.primaryResponsibility)
          ]
        }),
        ...(showNote ? [
          new Paragraph({ children: [new TextRun({ text: `What's in it for You:`, bold: true })] }),
          ...form.whatsInItForYou.split('\n').map(line => 
            new Paragraph({ 
              text: line.replace(/^•\s*/, ''),
              bullet: { level: 0 }
            })
          )
        ] : []),
        new Paragraph({ children: [new TextRun({ text: `What You'll Do:`, bold: true })] }),
        ...form.whatYouDo.split('\n').filter(line => line.trim()).map(line => 
          new Paragraph({ 
            text: line.replace(/^•\s*/, ''),
            bullet: { level: 0 }
          })
        ),
        new Paragraph({ children: [new TextRun({ text: `What Qualifies You:`, bold: true })] }),
        ...form.whatQualifiesYou.split('\n').filter(line => line.trim()).map(line => 
          new Paragraph({ 
            text: line.replace(/^•\s*/, ''),
            bullet: { level: 0 }
          })
        ),
        ...(!showNote ? [
          new Paragraph({ children: [new TextRun({ text: `What's in it for You:`, bold: true })] }),
          ...form.whatsInItForYou.split('\n').filter(line => line.trim()).map(line => 
            new Paragraph({ 
              text: line.replace(/^•\s*/, ''),
              bullet: { level: 0 }
            })
          )
        ] : []),
        ...(form.physicalDemands ? [
          new Paragraph({ children: [new TextRun({ text: `Physical Demands and Requirements:`, bold: true })] }),
          ...form.physicalDemands.split('\n').filter(line => line.trim()).map(line => 
            new Paragraph({ 
              text: line.replace(/^•\s*/, ''),
              bullet: { level: 0 }
            })
          )
        ] : []),
        ...(form.technicalSkills ? [
          new Paragraph({ children: [new TextRun({ text: `Technical Skill Requirements:`, bold: true })] }),
          ...form.technicalSkills.split('\n').filter(line => line.trim()).map(line => 
            new Paragraph({ 
              text: line.replace(/^•\s*/, ''),
              bullet: { level: 0 }
            })
          )
        ] : []),
        ...(form.educationLicensing ? [
          new Paragraph({ children: [new TextRun({ text: `Educational/Licensing Requirements:`, bold: true })] }),
          ...form.educationLicensing.split('\n').filter(line => line.trim()).map(line => 
            new Paragraph({ 
              text: line.replace(/^•\s*/, ''),
              bullet: { level: 0 }
            })
          )
        ] : []),
        ...(form.workingConditions ? [
          new Paragraph({ children: [new TextRun({ text: `Working Conditions:`, bold: true })] }),
          ...form.workingConditions.split('\n').filter(line => line.trim()).map(line => 
            new Paragraph({ 
              text: line.replace(/^•\s*/, ''),
              bullet: { level: 0 }
            })
          )
        ] : []),
        ...(form.culturalValues ? [
          new Paragraph({ children: [new TextRun({ text: `Cultural Values:`, bold: true })] }),
          ...form.culturalValues.split('\n').filter(line => line.trim()).map(line => 
            new Paragraph({ 
              text: line.replace(/^•\s*/, ''),
              bullet: { level: 0 }
            })
          )
        ] : []),
        new Paragraph({
          children: [
            new TextRun({
              text: 'Equal Opportunity: MIRATECH is an equal opportunity employer and supports a diverse and inclusive workforce. All employment practices are based on qualification and merit, without regards to race, color, national origin, ancestry, religion, age, sex, gender identity, sexual orientation or preference, marital status or spousal affiliation, physical or mental disability, medical conditions, pregnancy, status as a protected veteran, genetic information, or citizenship within the limits imposed by federal laws and regulations.',
              italics: true
            })
          ]
        })
      ]
    }]
  });

  Packer.toBlob(doc).then(blob => saveAs(blob, 'job-description.docx'));
};