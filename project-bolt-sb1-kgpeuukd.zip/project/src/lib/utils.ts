import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const formatBullets = (text: string): string => {
  return text
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .map(line => `<div style="padding-left: 1.5em; text-indent: -1em;">• ${line.replace(/^•\s*/, '')}</div>`)
    .join('');
};