import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';
import { Document, Packer, Paragraph, TextRun } from 'docx';
import { saveAs } from 'file-saver';

interface FormData {
  reportsTo: string;
  collaboratesWith: string;
  primaryResponsibility: string;
  whatYouDo: string;
  whatQualifiesYou: string;
  whatsInItForYou: string;
  physicalDemands: string;
  technicalSkills: string;
  educationLicensing: string;
  workingConditions: string;
  culturalValues: string;
}

interface PreviewCardProps {
  output: string;
  form: FormData;
  showNote: boolean;
}

const PreviewCard: React.FC<PreviewCardProps> = ({ output, form, showNote }) => {
  const downloadAsWord = () => {
    const paragraphs = [
      new Paragraph({ children: [new TextRun({ text: `Reports to: ${form.reportsTo}`, bold: true })] }),
      new Paragraph({ children: [new TextRun({ text: `Collaborates with: ${form.collaboratesWith}`, bold: true })] }),
      new Paragraph({ children: [new TextRun({ text: `Primary Responsibility: ${form.primaryResponsibility}`, bold: true })] }),
    ];

    if (showNote) {
      paragraphs.push(new Paragraph({ children: [new TextRun({ text: `What's in it for You:`, bold: true })] }));
      form.whatsInItForYou.split('\n').forEach(line => {
        if (line.trim()) {
          paragraphs.push(new Paragraph({ 
            text: line.replace(/^•\s*/, ''), 
            bullet: { level: 0 } 
          }));
        }
      });
    }

    paragraphs.push(new Paragraph({ children: [new TextRun({ text: `What You'll Do:`, bold: true })] }));
    form.whatYouDo.split('\n').forEach(line => {
      if (line.trim()) {
        paragraphs.push(new Paragraph({ 
          text: line.replace(/^•\s*/, ''), 
          bullet: { level: 0 } 
        }));
      }
    });

    paragraphs.push(new Paragraph({ children: [new TextRun({ text: `What Qualifies You:`, bold: true })] }));
    form.whatQualifiesYou.split('\n').forEach(line => {
      if (line.trim()) {
        paragraphs.push(new Paragraph({ 
          text: line.replace(/^•\s*/, ''), 
          bullet: { level: 0 } 
        }));
      }
    });

    if (!showNote) {
      paragraphs.push(new Paragraph({ children: [new TextRun({ text: `What's in it for You:`, bold: true })] }));
      form.whatsInItForYou.split('\n').forEach(line => {
        if (line.trim()) {
          paragraphs.push(new Paragraph({ 
            text: line.replace(/^•\s*/, ''), 
            bullet: { level: 0 } 
          }));
        }
      });
    }

    const optionalSections = [
      { label: 'Physical Demands and Requirements', content: form.physicalDemands },
      { label: 'Technical Skill Requirements', content: form.technicalSkills },
      { label: 'Educational/Licensing Requirements', content: form.educationLicensing },
      { label: 'Working Conditions', content: form.workingConditions },
      { label: 'Cultural Values', content: form.culturalValues }
    ];

    optionalSections.forEach(section => {
      if (section.content) {
        paragraphs.push(new Paragraph({ children: [new TextRun({ text: section.label + ':', bold: true })] }));
        section.content.split('\n').forEach(line => {
          if (line.trim()) {
            paragraphs.push(new Paragraph({ 
              text: line.replace(/^•\s*/, ''), 
              bullet: { level: 0 } 
            }));
          }
        });
      }
    });

    paragraphs.push(
      new Paragraph({
        children: [
          new TextRun({
            text:
              'Equal Opportunity: MIRATECH is an equal opportunity employer and supports a diverse and inclusive workforce. All employment practices are based on qualification and merit, without regards to race, color, national origin, ancestry, religion, age, sex, gender identity, sexual orientation or preference, marital status or spousal affiliation, physical or mental disability, medical conditions, pregnancy, status as a protected veteran, genetic information, or citizenship within the limits imposed by federal laws and regulations.',
            italics: true
          })
        ]
      })
    );

    const doc = new Document({ sections: [{ children: paragraphs }] });
    Packer.toBlob(doc).then(blob => saveAs(blob, 'job-description.docx'));
  };

  return (
    <Card className="mt-8 bg-white shadow-md transition-all duration-300 hover:shadow-lg">
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-800">Standardized Job Description</h2>
          <Button 
            onClick={downloadAsWord}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 transition-colors duration-200"
          >
            <Download className="h-4 w-4" />
            Download as Word
          </Button>
        </div>
        <div 
          dangerouslySetInnerHTML={{ __html: output }} 
          className="prose max-w-none text-gray-700 text-sm leading-relaxed"
          style={{ fontFamily: 'Verdana', fontSize: '9pt', lineHeight: '1.4' }} 
        />
      </CardContent>
    </Card>
  );
};

export default PreviewCard;