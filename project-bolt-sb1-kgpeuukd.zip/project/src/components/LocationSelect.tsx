import React, { useState } from 'react';
import { Select, SelectTrigger, SelectContent, SelectItem } from '@/components/ui/select';
import { BENEFITS_MAP } from '@/lib/benefits';

interface LocationSelectProps {
  value: string;
  onChange: (value: string) => void;
}

const LocationSelect: React.FC<LocationSelectProps> = ({ value, onChange }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (selectedValue: string) => {
    onChange(selectedValue);
    setIsOpen(false);
  };

  return (
    <div className="mb-4">
      <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
        Location/Position Type
      </label>
      <Select>
        <SelectTrigger 
          value={value}
          onClick={() => setIsOpen(!isOpen)}
          className="w-full transition-all duration-200 focus:border-blue-500"
        >
          {value || "Select a location"}
        </SelectTrigger>
        {isOpen && (
          <SelectContent 
            className="w-full max-h-60 mt-1" 
            onClose={() => setIsOpen(false)}
          >
            {Object.keys(BENEFITS_MAP).map((location) => (
              <SelectItem 
                key={location} 
                value={location}
                selected={location === value}
                onSelect={handleSelect}
                className="cursor-pointer hover:bg-gray-100 transition-colors duration-150"
              >
                {location}
              </SelectItem>
            ))}
          </SelectContent>
        )}
      </Select>
    </div>
  );
};

export default LocationSelect;