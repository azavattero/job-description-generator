import React from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';

interface FormFieldProps {
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  multiline?: boolean;
  rows?: number;
  isBulletField?: boolean;
  onFocus?: (e: React.FocusEvent<HTMLTextAreaElement | HTMLInputElement>) => void;
  placeholder?: string;
}

const FormField: React.FC<FormFieldProps> = ({
  label,
  name,
  value,
  onChange,
  multiline = false,
  rows = 3,
  isBulletField = false,
  onFocus,
  placeholder
}) => {
  return (
    <div className="mb-4">
      <div className="flex justify-between items-center mb-1">
        <label htmlFor={name} className="block text-sm font-medium text-gray-700">
          {label}
        </label>
        {isBulletField && (
          <Button 
            type="button" 
            variant="ghost" 
            size="sm"
            className="text-blue-600 hover:text-blue-800 transition-colors duration-200"
            onClick={(e) => {
              e.preventDefault();
              const textArea = document.querySelector(`textarea[name="${name}"]`) as HTMLTextAreaElement;
              if (textArea) {
                textArea.focus();
                const start = textArea.selectionStart;
                const end = textArea.selectionEnd;
                const value = textArea.value;
                const newValue = value.substring(0, start) + '• ' + value.substring(end);
                
                const event = {
                  target: {
                    name,
                    value: newValue
                  }
                } as React.ChangeEvent<HTMLTextAreaElement>;
                onChange(event);
                
                setTimeout(() => {
                  textarea.focus();
                  textarea.selectionStart = textarea.selectionEnd = start + 2;
                }, 0);
              }
            }}
          >
            <PlusCircle className="h-4 w-4 mr-1" />
            <span>Add Bullet</span>
          </Button>
        )}
      </div>
      {multiline ? (
        <Textarea
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          onFocus={onFocus as React.FocusEventHandler<HTMLTextAreaElement>}
          className="w-full transition-all duration-200 focus:border-blue-500"
          rows={rows}
          placeholder={placeholder}
        />
      ) : (
        <Input
          type="text"
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          onFocus={onFocus as React.FocusEventHandler<HTMLInputElement>}
          className="w-full transition-all duration-200 focus:border-blue-500"
          placeholder={placeholder}
        />
      )}
    </div>
  );
};

export default FormField;